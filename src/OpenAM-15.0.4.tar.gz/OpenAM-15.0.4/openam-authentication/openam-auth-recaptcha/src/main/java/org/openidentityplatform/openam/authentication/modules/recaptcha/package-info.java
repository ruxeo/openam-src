/**
 * 
 */
/**
 * @author maximthomas
 *
 */
package org.openidentityplatform.openam.authentication.modules.recaptcha;